/**********************************************************************
 *                                                                    *
 *  Vertices for model:                                               *
 *     ./mario/nin/display/nintendo_logo.nin                          *
 *                                                                    *
 *  THIS FILE WAS CREATED BY NINGEN                                   *
 *                                                                    *
 *    0 vertices,      0 bytes                                        *
 *                                                                    *
 **********************************************************************/


#include <mbi.h>

