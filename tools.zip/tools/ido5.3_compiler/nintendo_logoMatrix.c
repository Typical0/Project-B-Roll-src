
/**********************************************************************
 *                                                                    *
 *  Model ./mario/nin/display/nintendo_logo.nin                      *
 *    has no matrices                                                 *
 *                                                                    *
 *  THIS FILE WAS CREATED BY NINGEN                                   *
 *                                                                    *
 **********************************************************************/

