#ifndef MODEL_H
#define MODEL_H


#include <mbi.h>
#include <napp.h>


typedef struct {
	Nin *main_data;
	float *main_box;
}  Model, *Modelpt;





#endif /* MODEL_H */
